package com.bank.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import com.bank.DTO.TransactionDetails;
import com.bank.util.DatabaseConnection;

public class TransactionDetailsDAO {

	final private static String insert_Details = "insert into transaction_details (transaction_Type, transaction_amount, transaction_Time, transaction_Date, balance_Amount, transaction_status, customer_Account_Number) values(?,?,?,?,?,?,?)";
	final private static String selectDetails=" select * from transaction_details where customer_Account_Number=?";
	
	public boolean insertTransactionDetails(TransactionDetails transactionDetails) {
		try {

			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(insert_Details);
			preparedStatement.setString(1, transactionDetails.getTransactionType());
			preparedStatement.setDouble(2, transactionDetails.getTransactionAmount());
			preparedStatement.setTime(3, Time.valueOf(transactionDetails.getTransactionTime()));
			preparedStatement.setDate(4, Date.valueOf(transactionDetails.getTransactionDate()));
			preparedStatement.setDouble(5, transactionDetails.getBalanceAmount());
			preparedStatement.setString(6, transactionDetails.getTransactionStatus());
			preparedStatement.setLong(7, transactionDetails.getCustomerAccountNumber());
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public void transactionDetails(long accnum) {
		
	try {
		Connection connection=	DatabaseConnection.forMySqlConnection();
		PreparedStatement preparedStatement=connection.prepareStatement(selectDetails);
		preparedStatement.setLong(1, accnum);
		ResultSet resultSet= preparedStatement.executeQuery();
		if(resultSet.next()) {
			System.out.println(resultSet.getString("transaction_Type"));
			System.out.println(resultSet.getDouble("transaction_amount"));
			System.out.println(resultSet.getDouble("transaction_amount"));
			System.out.println(resultSet.getTime("transaction_Time"));
			System.out.println(resultSet.getDate("transaction_Date"));
			System.out.println(resultSet.getDouble("balance_Amount"));
			System.out.println(resultSet.getString("transaction_status"));
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
