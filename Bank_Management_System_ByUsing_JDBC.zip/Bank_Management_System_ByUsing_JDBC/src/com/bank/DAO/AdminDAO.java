package com.bank.DAO;

import java.net.MulticastSocket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import com.bank.util.DatabaseConnection;

public class AdminDAO {
	
	
	private static final String adminLogin ="select * from admindetails where emailid=? and password=?";
	private static final String allCustomerDetails ="select * from customerdetails";
	private static final String accountNum="update admindetails set Customer_AccountNum=accnum and Customer_Pin=pin where status='Pending";
	public boolean selectAdminDetailsByUsingEmailidAndPassword(String email , String password) {
		
		try {
			Connection connection=DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(adminLogin);
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.isBeforeFirst()) {
				return true;
			}else {
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
    public void getAllCustomerDetails(String status) {
    	try {
			Connection connection=DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(allCustomerDetails);
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.isBeforeFirst()) {
				while(resultSet.next()) {
					if(resultSet.getString("customer_Status").equalsIgnoreCase(status)) {
					System.out.println("Customer name : "+resultSet.getString("Customer_Name"));
					System.out.println("Customer Email : "+resultSet.getString("Customer_Emailid"));
					System.out.println("Customer Mobile number : "+resultSet.getLong("Customer_MobileNum"));
					System.out.println("Customer Aadhar number : "+resultSet.getLong("Customer_AdharNum"));
					System.out.println("Customer Address : "+resultSet.getString("Customer_Address"));
					System.out.println("Customer Gender : "+resultSet.getString("Customer_Gender"));
					System.out.println("Customer Account number : "+resultSet.getLong("Customer_AccountNum"));
					System.out.println("Customer Account Balance : "+resultSet.getInt("Customer_Amount"));
					System.out.println("Customer status  :  "+ resultSet.getString("customer_Status"));
					System.out.println();
					System.out.println("************************************************************************");
					System.out.println();
					}	
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public static void genrateAccountNumber(int id)
	{
		Random r=new Random();
		long accountNumber=r.nextInt(9000000)+1000000l;
		int pin=r.nextInt(9000)+1000;
		int otp=r.nextInt(9000000)+1000000;
		
		String Assign_Account_Number="update customerdetails set Customer_AccountNum=?,Customer_Pin=?,customer_Status=? where Customer_Id=? and customer_Status=?";
		
		try {
			Connection connection=DatabaseConnection.forMySqlConnection();
			PreparedStatement ps=connection.prepareStatement(Assign_Account_Number);
			ps.setLong(1, accountNumber);
			ps.setInt(2, pin);
			ps.setString(3, "Active");
			ps.setInt(4, id);
			ps.setString(5, "Pending");
			int res=ps.executeUpdate();
			if(res!=0)
			{
				System.out.println("Account Number And Pin Is Assigined to the Customer id:"+id);
			}
			else
			{
				System.out.println("Id Not Found!");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    public  void generateAountNumAndPinNum(String status) {
    	
    		Random r=new Random();
    		
    		
    		String selectId="select Customer_Id from customerdetails where customer_Status=?";
    		String Assign_AccNum="update customerdetails set Customer_AccountNum=?,Customer_Pin=? ,customer_Status=? where customer_Status=? and Customer_Id=?";
    		
    		try {
    			boolean updated=false;
    			Connection connection=DatabaseConnection.forMySqlConnection();
    			PreparedStatement preparedStatement=connection.prepareStatement(selectId);
    			preparedStatement.setString(1, status);
    			ResultSet rs=preparedStatement.executeQuery();
    			PreparedStatement ps=connection.prepareStatement(Assign_AccNum);
    			while(rs.next())
    			{
    			
    			long accountNumber=r.nextInt(9000000)+1000000l;
    			int pin=r.nextInt(9999);
    			int otp=r.nextInt(99999999);
    			ps.setLong(1, accountNumber);
    			ps.setInt(2, pin);
    			ps.setString(3, "Active");
    			ps.setString(4, status);
    			int id=rs.getInt("Customer_Id");
    			ps.setInt(5, id);
    			
    			ps.addBatch();
    			updated=true;
    			}
    			if(updated)
    			{
    			int[] res=ps.executeBatch();
    			
    			
    			if(res.length!=0)
    			{
    				System.out.println("Account Number And Pin Is Assigined to All Requsted Customers");
    			}
    			else
    			{
    				System.err.println(" Server Error!");
    			}
    			}
    			
    		} catch (ClassNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	}
    }

