package com.bank.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bank.DTO.CustomerDetails;
import com.bank.util.DatabaseConnection;

import javafx.scene.chart.PieChart.Data;

public class CustomerDAO {

	final private static String select_all_details = "select * from customerdetails";

	final private static String insert = "insert into customerdetails(Customer_Name, Customer_Emailid, Customer_MobileNum,"
			+ " Customer_AdharNum, Customer_Address, Customer_Gender, Customer_Amount,customer_Status)"
			+ "values(?,?,?,?,?,?,?,'pending')";

	final private static String customerLogin = "select * from customerdetails "
			+ "where (Customer_Emailid=? or Customer_AccountNum=?) and Customer_Pin=?";

	final private static String balance = "select * from customerdetails where Customer_Pin=?";

	final private static String credit = "select * from customerdetails where  Customer_AccountNum=? and Customer_Pin=?";
	final private static String debit = "select * from customerdetails where  Customer_AccountNum=? and Customer_Pin=?";
	final private static String debitUpdateAmount = "update customerdetails set Customer_Amount=? where Customer_Pin=?";
    final private static String updatePin="update customerdetails set Customer_Pin=? where Customer_Pin=?";
    final private static String deleteAccount="delete from  customerdetails where Customer_AccountNum=? and Customer_Pin=?";
    
	public boolean insertCustomerDetails(CustomerDetails customerDetails) {
		// insertion

		try {
			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(insert);
			preparedStatement.setString(1, customerDetails.getName());
			preparedStatement.setString(2, customerDetails.getEmailId());
			preparedStatement.setLong(3, customerDetails.getMobileNum());
			preparedStatement.setLong(4, customerDetails.getAadharNum());
			preparedStatement.setString(5, customerDetails.getAddress());
			preparedStatement.setString(6, customerDetails.getGender());
			preparedStatement.setDouble(7, customerDetails.getAmount());
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}

	public List<CustomerDetails> getAllCustomerDetails() {

		try {
			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(select_all_details);
			ResultSet resultSet = preparedStatement.executeQuery();
			List<CustomerDetails> listOfCustomerDetails = new ArrayList<CustomerDetails>();
			if (resultSet.isBeforeFirst()) {
				while (resultSet.next()) {
					CustomerDetails customerDetails = new CustomerDetails();
					customerDetails.setEmailId(resultSet.getString("Customer_Emailid"));
					customerDetails.setMobileNum(resultSet.getLong("Customer_MobileNum"));
					customerDetails.setAadharNum(resultSet.getLong("Customer_AdharNum"));
					listOfCustomerDetails.add(customerDetails);
				}
				return listOfCustomerDetails;
			} else {
				return null;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public CustomerDetails selectCustomerDetailsByUsingEmailIdOrAccountNum(String email, int pin) {
		try {
			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(customerLogin);
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, email);
			preparedStatement.setInt(3, pin);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				String gender = resultSet.getString("Customer_Gender");
				String name = resultSet.getString("Customer_Name");
				long accnum = resultSet.getLong("Customer_AccountNum");
				double amount = resultSet.getDouble("Customer_Amount");
				int pin1 = resultSet.getInt("Customer_Pin");
				CustomerDetails customerDetails = new CustomerDetails();
				customerDetails.setName(name);
				customerDetails.setGender(gender);
				customerDetails.setAccountNum(accnum);
				customerDetails.setAmount(amount);
				customerDetails.setPin(pin1);
				return customerDetails;
			} else {
				return null;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public boolean debit(long accountNum, int pin) {
		try {
			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(debit);
			preparedStatement.setLong(1, accountNum);
			preparedStatement.setInt(2, pin);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.isBeforeFirst()) {
				return true;
			} else {
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public boolean updateAmountAfterDebitAndCredit(double amount, int pin) {

		try {
			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(debitUpdateAmount);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setInt(2, pin);
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public boolean customerBalance(long accnum, int pin) {
		try {
			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(balance);
			preparedStatement.setLong(1, accnum);
			preparedStatement.setInt(2, pin);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				return true;
			} else {
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public boolean credit(long accountnum, int pin) {
		try {
			Connection connection = DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(credit);
			preparedStatement.setLong(1, accountnum);
			preparedStatement.setInt(2, pin);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.isBeforeFirst()) {
				return true;
			} else {
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public boolean updatePinByUsingOldPin(int pin) {
		
		try {
			Connection connection=DatabaseConnection.forMySqlConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(updatePin);
			preparedStatement.setInt(1, pin);
			int result=preparedStatement.executeUpdate();
			if(result!=0) {
				return true;
			}else {
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public boolean  accountDelete(long accnum , int pin) {
		
		try {
		Connection connection=DatabaseConnection.forMySqlConnection();
		PreparedStatement preparedStatement=connection.prepareStatement(deleteAccount);
		preparedStatement.setLong(1, accnum);
		preparedStatement.setInt(2, pin);
		int result=preparedStatement.executeUpdate();
		if(result!=0) {
			return true;
		}else {
			return false;
		}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
}
