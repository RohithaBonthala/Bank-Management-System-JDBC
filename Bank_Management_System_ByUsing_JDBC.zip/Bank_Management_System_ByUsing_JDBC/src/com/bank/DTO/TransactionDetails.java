package com.bank.DTO;

import java.time.LocalDate;
import java.time.LocalTime;

public class TransactionDetails {

	private int transactionid;
	private String transactionType;
	private double transactionAmount;
	private LocalDate transactionDate;
	private LocalTime transactionTime;
	private double balanceAmount;
	private String transactionStatus;
	private long customerAccountNumber;

	public TransactionDetails() {
	}

	public TransactionDetails(int transactionid, String transactionType, double transactionAmount,
			LocalDate transactionDate, LocalTime transactionTime, double balanceAmount, String transactionStatus,
			long customerAccountNumber) {
		this.transactionid = transactionid;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.transactionDate = transactionDate;
		this.transactionTime = transactionTime;
		this.balanceAmount = balanceAmount;
		this.transactionStatus = transactionStatus;
		this.customerAccountNumber = customerAccountNumber;
	}

	public int getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public LocalTime getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(LocalTime transactionTime) {
		this.transactionTime = transactionTime;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public long getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(long customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	@Override
	public String toString() {
		return "TransactionDetails [transactionid=" + transactionid + ", transactionType=" + transactionType
				+ ", transactionAmount=" + transactionAmount + ", transactionDate=" + transactionDate
				+ ", transactionTime=" + transactionTime + ", balanceAmount=" + balanceAmount + ", transactionStatus="
				+ transactionStatus + ", customerAccountNumber=" + customerAccountNumber + "]";
	}
  
}
