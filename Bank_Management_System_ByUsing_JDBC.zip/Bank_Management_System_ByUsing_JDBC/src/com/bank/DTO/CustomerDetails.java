package com.bank.DTO;

public class CustomerDetails {

	private String name;
	private String emailId;
	private long mobileNum;
	private long aadharNum;
	private String address;
	private String gender;
	private long accountNum;
	private double amount;
	private int pin;
	private String status;
	
	public CustomerDetails() {}
	
	public CustomerDetails(String name, String emailId, long mobileNum, long aadharNum, String address, String gender,
			long accountNum, double amount, int pin,String status) {
		super();
		this.name = name;
		this.emailId = emailId;
		this.mobileNum = mobileNum;
		this.aadharNum = aadharNum;
		this.address = address;
		this.gender = gender;
		this.accountNum = accountNum;
		this.amount = amount;
		this.pin = pin;
		this.status=status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(long mobileNum) {
		this.mobileNum = mobileNum;
	}
	public long getAadharNum() {
		return aadharNum;
	}
	public void setAadharNum(long aadharNum) {
		this.aadharNum = aadharNum;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(long accountNum) {
		this.accountNum = accountNum;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "CustomerDetails [name=" + name + ", emailId=" + emailId + ", mobileNum=" + mobileNum + ", aadharNum="
				+ aadharNum + ", address=" + address + ", gender=" + gender + ", accountNum=" + accountNum + ", amount="
				+ amount + ", pin=" + pin + ", status=" + status + "]";
	}

	
}
