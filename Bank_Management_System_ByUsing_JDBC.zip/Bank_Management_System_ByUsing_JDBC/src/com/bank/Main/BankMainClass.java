package com.bank.Main;

import java.util.Scanner;

import com.bank.DAO.AdminDAO;
import com.bank.service.AdminService;
import com.bank.service.CustomerService;

public class BankMainClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		CustomerService customerService=new CustomerService();
		AdminService adminService=new AdminService();
		//customerService.customerRegistraction();
		System.out.println("Enter \n 1. For Customer Registraction \n 2. For Customer Login \n 3. For Admin Login");
		switch(sc.nextInt()) {
		
		case 1:{
			System.out.println(" Customer Registraction");
			customerService.customerRegistraction();
			break;
		}
		case 2:{
			System.out.println(" Customer Login");
			customerService.custumerLogin();
			break;
		}
		case 3:{
			System.out.println(" Admin Login");
			adminService.adminLogin();
			break;
		}
		default :{
			System.out.println("Invalid request");
			break;
		}
	  }
		sc.close();
	}
}
