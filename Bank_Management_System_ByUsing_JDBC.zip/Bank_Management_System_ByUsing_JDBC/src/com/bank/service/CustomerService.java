package com.bank.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

import com.bank.DAO.CustomerDAO;
import com.bank.DAO.TransactionDetailsDAO;
import com.bank.DTO.CustomerDetails;
import com.bank.DTO.TransactionDetails;
import com.bank.exception.CustomerDataInvalidException;
import com.bank.util.DatabaseConnection;

public class CustomerService {

	CustomerDetails customerDetails = new CustomerDetails();
	CustomerDAO customerDAO = new CustomerDAO();
	TransactionDetailsDAO transactionDetailsDAO=new TransactionDetailsDAO();
	Scanner sc = new Scanner(System.in);

	public void customerRegistraction() {

		// to take the values from the customer
		/* to set all the details inside the object to transfer from service to DAO */
		List<CustomerDetails> allCustomerDetails = customerDAO.getAllCustomerDetails();
		CustomerDetails customerDetails = new CustomerDetails();
		String status = "pending..";
		customerDetails.setStatus(status);
		System.out.println("Enter Customer name");
		while (true) {
			try {
				String name = sc.next();
				if (name.matches("[A-Za-z]+")) {
					customerDetails.setName(name);
					break;
				} else {
					throw new CustomerDataInvalidException("Invalid Name");
				}
			} catch (CustomerDataInvalidException e) {
				System.out.println(e.getExceptionMsg());
				System.out.println("re-enter the name");
			}
		}
		System.out.println("Enter Customer EmailId");
		while (true) {
			try {
				String email = sc.next();
				if (email.endsWith("@gmail.com")) {
					for (CustomerDetails c : allCustomerDetails) {
						if (!c.getEmailId().equalsIgnoreCase(email)) {
							customerDetails.setEmailId(email);
						} else {
							throw new CustomerDataInvalidException("Duplicate EmailId");
						}
					}
					break;
				} else {
					throw new CustomerDataInvalidException("Invalid EmailId");
				}
			} catch (CustomerDataInvalidException e) {
				System.out.println(e.getExceptionMsg());
				System.out.println("re-enter the email");
			}
		}
		System.out.println("Enter Customer Mobile Number");
		while (true) {
			try {
				long mobileNum = sc.nextLong();
				if (mobileNum >= 6000000000l && mobileNum <= 9999999999l) {
					for (CustomerDetails c : allCustomerDetails) {
						if (!(c.getMobileNum() == mobileNum)) {
							customerDetails.setMobileNum(mobileNum);
						} else {
							throw new CustomerDataInvalidException("Duplicate mobile number");
						}
					}
					break;
				} else {
					/* create user defined Exception class in exception package */
					throw new CustomerDataInvalidException("Invalid mobile number");
				}
			} catch (CustomerDataInvalidException e) {
				System.out.println(e.getExceptionMsg());
				System.out.println("re-enter the mobile number");
			}
		}
		while (true) {
			try {
				System.out.println("Enter Customer Aadhar Number");
				long aadharNum = sc.nextLong();
				if (aadharNum >= 100000000000l && aadharNum <= 999999999999l) {

					for (CustomerDetails c : allCustomerDetails) {
						if (!(c.getAadharNum() == aadharNum)) {
							customerDetails.setAadharNum(aadharNum);
						} else {
							throw new CustomerDataInvalidException("Duplicate Adhar number");
						}
					}
					break;
				} else {
					throw new CustomerDataInvalidException("Invalid Aadhar number");
				}
			} catch (CustomerDataInvalidException e) {
				System.out.println(e.getExceptionMsg());
				System.out.println("re-enter the mobile number");
			}
		}
		while (true) {
			try {
				System.out.println("Enter Customer Address");
				String adress = sc.next();

				System.out.println("Enter Customer Gender");
				String gender = sc.next();
				customerDetails.setAddress(adress);

				if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female")
						|| gender.equalsIgnoreCase("others")) {
					customerDetails.setGender(gender);
					break;
				} else {
					throw new CustomerDataInvalidException("Invalid  gender");
				}
			} catch (CustomerDataInvalidException e) {
				System.out.println(e.getExceptionMsg());
				System.out.println("re-enter the gender");
			}
		}
		while (true) {
			try {
				System.out.println("Enter Customer amount");
				double amount = sc.nextDouble();
				if (amount >= 0) {
					customerDetails.setAmount(amount);
					break;
				} else {
					throw new CustomerDataInvalidException("Invalid Amount");
				}
			} catch (CustomerDataInvalidException e) {
				System.out.println(e.getExceptionMsg());
				System.out.println("re-enter the amount");
			}
		}
		if (customerDAO.insertCustomerDetails(customerDetails)) {

			System.out.println("Data inserted");
		} else {
			System.err.println("Server Error");
		}
	}

	public void custumerLogin() {
		System.out.println("Enter  EmailId or Account Number");
		String emailidORaccNum = sc.next();
		System.out.println("Enter  Pin");
		int pin = sc.nextInt();
		CustomerDetails customerDetails = customerDAO.selectCustomerDetailsByUsingEmailIdOrAccountNum(emailidORaccNum,
				pin);
		if (customerDetails != null) {
			String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			StringBuilder result = new StringBuilder();
			Random random = new Random();
			for (int i = 0; i < 4; i++) {
				int index = random.nextInt(characters.length());
				result.append(characters.charAt(index));
			}
			System.out.println("CAPTCHA :" + result);
			System.out.println("Enter Captcha");
			String s = sc.next();
			if (s.equals(result.toString())) {
				if (customerDetails.getGender().equalsIgnoreCase("male")) {
					System.out.println("Hello \n Mr :-" + customerDetails.getName());
					customerOperations(customerDetails);
				}
				if (customerDetails.getGender().equalsIgnoreCase("Female")) {
					System.out.println("Hello \n Miss :-" + customerDetails.getName());
					customerOperations(customerDetails);
				}
			} else {
				System.out.println("Invalid captcha");
			}
		} else {
			System.out.println("invalid Credendials");
		}
	}

	public void customerOperations(CustomerDetails customerDetails) {

		boolean start = true;
		while (start) {
			System.out.println("Enter " + "\n 1 For credit" + "\n 2 For Debit" + "\n 3 For Check Statment"
					+ "\n 4 For Check Balance" + "\n 5 Update PIN" + "\n 6 Close Account" + "\n 7 back");
			switch (sc.nextInt()) {
			case 1:
				System.out.println("Credit");
				creditAmount(customerDetails);
				break;
			case 2:
				System.out.println("Debit");
				debitAmount(customerDetails);
				break;
			case 3:
				System.out.println("Check Statment");
				checkStatment(customerDetails);
				break;
			case 4:
				System.out.println("Check Balance");
				checkBalance(customerDetails);
				break;
			case 5:
				System.out.println("Update PIN");
				updatePin(customerDetails);
				break;
			case 6:
				System.out.println("Close Account");
				deleteAccount(customerDetails);
				break;
			case 7: {
				System.out.println("Back");
				start = false;
				break;
			}
			default:
				System.out.println("Invalid Request");
				break;
			}
		}
	}

	public void debitAmount(CustomerDetails customerDetails) {
		System.out.println("Enter the Account number ");
		long accnum = sc.nextLong();
		System.out.println("Enter the Pin");
		int pin = sc.nextInt();
		if (customerDetails.getAccountNum() == accnum) {
			if (customerDAO.debit(accnum, pin)) {
				System.out.println("Enter the Amount");
				int amount = sc.nextInt();
				if (amount > 0) {
					if (amount < customerDetails.getAmount()) {
						double updateAmount = customerDetails.getAmount() - amount;
						if(customerDAO.updateAmountAfterDebitAndCredit(updateAmount, pin)) {
							TransactionDetails transactionDetails=new TransactionDetails();
							transactionDetails.setTransactionType("DEBIT");
							transactionDetails.setTransactionAmount(amount);
							transactionDetails.setBalanceAmount(updateAmount);
							transactionDetails.setTransactionDate(LocalDate.now());
							transactionDetails.setTransactionTime(LocalTime.now());
							transactionDetails.setCustomerAccountNumber(accnum);
							transactionDetails.setTransactionStatus("Transfered");
							transactionDetailsDAO.insertTransactionDetails(transactionDetails);
							System.out.println("Amount withDraw Successfully....");
						}else {
							System.out.println("server error");
						}
					} else {
						System.out.println("In-suffient balance");
				}
			}else {
					System.out.println("Invalid Amount");
				}
			}
		} else {
			System.out.println("Account Number miss Match for login ");
		}
	}
	
	public void creditAmount(CustomerDetails customerDetails) {

		System.out.println("Enter the Account number ");
		long accnum = sc.nextLong();
		System.out.println("Enter the Pin");
		int pin = sc.nextInt();
		if (customerDetails.getAccountNum() == accnum) {
			if (customerDAO.credit(accnum, pin)) {
				System.out.println("Enter the Amount");
				int amount = sc.nextInt();
				if (amount > 0) {
					double updateAmount = customerDetails.getAmount() + amount;
					if (customerDAO.updateAmountAfterDebitAndCredit(updateAmount, pin)) {
						TransactionDetails transactionDetails=new TransactionDetails();
						transactionDetails.setTransactionType("CREDIT");
						transactionDetails.setTransactionAmount(amount);
						transactionDetails.setBalanceAmount(updateAmount);
						transactionDetails.setTransactionDate(LocalDate.now());
						transactionDetails.setTransactionTime(LocalTime.now());
						transactionDetails.setCustomerAccountNumber(accnum);
						transactionDetails.setTransactionStatus("Credited");
						transactionDetailsDAO.insertTransactionDetails(transactionDetails);
						System.out.println("Amount Credit Successfully....");
					} else {
						System.out.println("service error");
					}
				} else {
					System.out.println("Invalid Amount ");
				}
			} else {
				System.out.println("Invalid Credendials");
			}
		} else {
			System.out.println("Account Number miss Match for login ");
		}
	}
	
	public void checkBalance(CustomerDetails customerDetails) {
		System.out.println("Enter Account Number");
		long accnum=sc.nextLong();
		System.out.println("Enter Pin");
		int pin = sc.nextInt();
		if (customerDetails.getAccountNum()==accnum && customerDetails.getPin()==pin) {
			System.out.println("Name : " + customerDetails.getName());
			System.out.println("Current Balance : " + customerDetails.getAmount() + " /-");
		} else {
			System.out.println("Invalid Pin");
		}
	}
	public void checkStatment(CustomerDetails customerDetails) {
		
		System.out.println("Enter Account Number");
		long accnum=sc.nextLong();
		System.out.println("Enter Pin");
		int pin = sc.nextInt();
		if (customerDetails.getAccountNum()==accnum && customerDetails.getPin()==pin) {
			transactionDetailsDAO.transactionDetails(accnum);
		}
	}
	public void updatePin(CustomerDetails customerDetails) {
		
		System.out.println("Enter Old  Pin");
		int pin = sc.nextInt();
		if(customerDetails.getPin()==pin) {
			System.out.println("Enter new Pin");
			int updatePin=sc.nextInt();
			if(customerDAO.updatePinByUsingOldPin(updatePin)) {
				System.out.println("Pin update successfully..");
			}else {
				System.out.println("Server error");
			}
		}else {
			System.out.println("invalid pin");
		}
	}
	public void deleteAccount(CustomerDetails customerDetails) {
		
		System.out.println("Enter Account Number");
		long accnum=sc.nextLong();
		System.out.println("Enter Pin");
		int pin = sc.nextInt();
		if (customerDetails.getAccountNum()==accnum && customerDetails.getPin()==pin) {
			if(customerDAO.accountDelete(accnum, pin)) {
				System.out.println("Account Delete successfully..");
			}else {
				System.out.println("server error");
			}
		}else {
			System.out.println("invalid pin or account num");
		}
		
	}
}
