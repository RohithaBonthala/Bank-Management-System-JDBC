package com.bank.service;

import java.util.Scanner;

import com.bank.DAO.AdminDAO;
import com.bank.DTO.CustomerDetails;

public class AdminService {
	
	Scanner sc=new Scanner(System.in);
	
	AdminDAO adminDAO=new AdminDAO();
	CustomerDetails customerDetails=new CustomerDetails();
	public void adminLogin() {
		
		System.out.println("enter the email");
		String email=sc.next();
		System.out.println("enter  password ");
		String password=sc.next();
		
		if(adminDAO.selectAdminDetailsByUsingEmailidAndPassword(email, password)) {
			System.out.println("Enter \n 1. To Get All Customer Details \n 2. To Get All Account Request Details \n 3. To Get All Account Closing Details");
			switch (sc.nextInt()) {
			case 1:{
				 System.out.println(" All Customer Details");
				 System.out.println();
				 adminDAO.getAllCustomerDetails("active");
				break;
			}
			case 2:
			{
				System.out.println(" All Account Request Details");
				 adminDAO.getAllCustomerDetails("pending");
				 System.out.println("Enter \n 1. Genrating Account Num & Pin For One Customer \n 2. Genrating Account Num & Pin For All Customers ");
				 int ch=sc.nextInt();
					switch(ch)
					{
					case 1:
					{
						System.out.println("Enter the Customer Id to genrate the Account Number:");
						int id=sc.nextInt();
						adminDAO.genrateAccountNumber(id);
					}
					break;
					case 2:
					{
						
						adminDAO.generateAountNumAndPinNum("pending");
					}
					break;
					}	
				}
			break;
			case 3:{
				System.out.println(" All Account closing Details");
				 adminDAO.getAllCustomerDetails("closing");
				break;
			}
			default:{
				System.out.println("Invalid Request");
				break;
			}
		}
		}else {
			System.out.println("invalid email and password");
		}
	}
}
